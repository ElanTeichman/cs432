#!/usr/bin/env bash
# Run from your project root, or pass actual and expected directory paths.
set -eu
script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec python3 "$script_dir/check_output.py" "$@"
