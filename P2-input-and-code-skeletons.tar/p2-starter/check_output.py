#!/usr/bin/env python3
"""Compare generated routing logs with supplied reference records."""
import argparse
from collections import Counter
import difflib
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('actual', nargs='?', default='output', type=Path)
    parser.add_argument('expected', nargs='?', default=Path(__file__).resolve().parent / 'expected-output', type=Path)
    parser.add_argument('--strict-order', action='store_true', help='also require the reference line order')
    args = parser.parse_args()
    if not args.actual.is_dir() or not args.expected.is_dir():
        parser.error('actual and expected directories must both exist')
    refs = sorted(args.expected.glob('*.txt'))
    if not refs:
        parser.error('expected directory contains no .txt reference files')
    failed = 0
    for ref in refs:
        actual = args.actual / ref.name
        if not actual.is_file():
            print(f'FAIL {ref.name}: missing file')
            failed += 1
            continue
        try:
            wanted = ref.read_text(encoding='utf-8').splitlines()
            got = actual.read_text(encoding='utf-8').splitlines()
        except (OSError, UnicodeError) as error:
            print(f'FAIL {ref.name}: {error}')
            failed += 1
            continue
        matches = wanted == got if args.strict_order else Counter(wanted) == Counter(got)
        if matches:
            print(f'PASS {ref.name} ({len(got)} records)')
        else:
            failed += 1
            print(f'FAIL {ref.name}')
            left, right = (wanted, got) if args.strict_order else (sorted(wanted), sorted(got))
            print(''.join(difflib.unified_diff([x+'\n' for x in left], [x+'\n' for x in right], fromfile='expected/'+ref.name, tofile='actual/'+ref.name)), end='')
    names = {p.name for p in refs}
    for actual in sorted(args.actual.glob('*.txt')):
        if actual.name not in names:
            try:
                if actual.read_text(encoding='utf-8'):
                    failed += 1
                    print(f'FAIL {actual.name}: unexpected nonempty .txt file')
            except (OSError, UnicodeError) as error:
                failed += 1
                print(f'FAIL {actual.name}: {error}')
    print(f'{len(refs)} reference files checked; {failed} failure(s).')
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
